#!/bin/sh -e
cp board/mini437x/u-boot.bin ${BINARIES_DIR}/u-boot.bin
